# 小磊子

黑发红巾的小少年，威风凛凛又爱调皮，陪你灵动开工。

此包为非官方自制宠物素材。PNG 为原始透明精灵图（1536×2288，8列×11行，每帧192×208）。

本机 Codex 使用的配置格式已包含在 pet.json。可把整个 xiaoleizi 文件夹复制到 Codex 的 pets 目录（默认 ~/.codex/pets/；自定义 CODEX_HOME 时使用其 pets 子目录），重启客户端后选择宠物。若已有同名目录，请先备份。移除时先切换到其他宠物，再删除此文件夹。

ChatGPT Work 请将 spritesheet.png 交给支持自定义宠物的 Agent，要求“使用此精灵图创建宠物”；支持情况和校验结果以当前客户端为准。素材包本身不会自动创建云端宠物。

仓库：https://github.com/Songhonglei/better-office-work/tree/main/smalljoys/pets

许可：MIT，见 LICENSE。
